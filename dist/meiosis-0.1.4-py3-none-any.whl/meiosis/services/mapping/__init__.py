from .standard_map import StandardMapper, BreadMapper, ImageMapper
__init__ = [ImageMapper, StandardMapper, BreadMapper]