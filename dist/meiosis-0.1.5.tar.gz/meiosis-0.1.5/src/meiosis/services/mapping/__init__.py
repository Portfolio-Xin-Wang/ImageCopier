from .standard_map import Mapper, BreadMapper, ImageMapper
__init__ = [ImageMapper, Mapper, BreadMapper]